// Geometric Tools, LLC
// Copyright (c) 1998-2014
// Distributed under the Boost Software License, Version 1.0.
// http://www.boost.org/LICENSE_1_0.txt
// http://www.geometrictools.com/License/Boost/LICENSE_1_0.txt
//
// File Version: 5.0.1 (2010/10/01)

#ifndef WM5WIRESTATE_H
#define WM5WIRESTATE_H

#include "Wm5GraphicsLIB.h"
#include "Wm5Object.h"

namespace Wm5
{

class WM5_GRAPHICS_ITEM WireState : public Object
{
    WM5_DECLARE_RTTI;
    WM5_DECLARE_NAMES;
    WM5_DECLARE_STREAM(WireState);

public:
    // Construction and destruction.
    WireState ();
    virtual ~WireState ();

    bool Enabled;  // default: false
};

WM5_REGISTER_STREAM(WireState);
typedef Pointer0<WireState> WireStatePtr;

}

#endif
